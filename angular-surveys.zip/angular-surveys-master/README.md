# angular-surveys
Angular.js survey / form builder inspired by Google Forms

[Bootstrap Demo](http://mwasiluk.github.io/angular-surveys)

[Material Design Demo](http://mwasiluk.github.io/angular-surveys/material)

## Bower

You can install this package through `Bower` :

    bower install angular-surveys --save

## Wiki
[Directives](https://github.com/mwasiluk/angular-surveys/wiki/Directives)
